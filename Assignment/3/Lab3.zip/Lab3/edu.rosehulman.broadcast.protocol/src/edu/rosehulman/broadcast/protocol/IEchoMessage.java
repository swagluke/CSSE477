package edu.rosehulman.broadcast.protocol;

public interface IEchoMessage extends IControlMessage {
	public String getContent();
}
