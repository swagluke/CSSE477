package edu.rosehulman.broadcast.protocol;

public interface IControlMessage extends IMessage {
	public String getUser();
}
