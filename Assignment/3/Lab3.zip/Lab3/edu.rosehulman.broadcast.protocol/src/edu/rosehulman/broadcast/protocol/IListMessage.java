package edu.rosehulman.broadcast.protocol;

public interface IListMessage extends IControlMessage {
	public String getContent();
}
